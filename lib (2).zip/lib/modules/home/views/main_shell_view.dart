import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../core/theme/app_colors.dart';
import '../../properties/views/properties_view.dart';
import '../../investments/views/investments_view.dart';
import '../views/home_view.dart';
import '../../profile/views/profile_view.dart';
import '../controllers/main_shell_controller.dart';

class MainShellView extends GetView<MainShellController> {
  const MainShellView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const _AppDrawer(),
      body: Obx(
        () => IndexedStack(
          index: controller.tabIndex.value,
          children:  [
            HomeView(),
            PropertiesView(),
            InvestmentsView(),
            ProfileView(),
          ],
        ),
      ),
      bottomNavigationBar: Obx(
        () => _BottomNav(
          selected: controller.tabIndex.value,
          onTap: controller.changeTab,
        ),
      ),
    );
  }
}

// ─── Drawer ───────────────────────────────────────────────────────────────────
class _AppDrawer extends StatelessWidget {
  const _AppDrawer();

  @override
  Widget build(BuildContext context) {
    final shell = Get.find<MainShellController>();
    return Drawer(
      backgroundColor: AppColors.background,
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 24, 20, 16),
              child: Text(
                'Bharat SQFT',
                style: TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
            const Divider(color: AppColors.divider),
            _DrawerItem(
              icon: Icons.home_rounded,
              label: 'Home',
              onTap: () {
                shell.changeTab(0);
                Get.back();
              },
            ),
            _DrawerItem(
              icon: Icons.apartment_outlined,
              label: 'Properties',
              onTap: () {
                shell.changeTab(1);
                Get.back();
              },
            ),
            _DrawerItem(
              icon: Icons.grid_view_rounded,
              label: 'My Bricks',
              onTap: () {
                shell.changeTab(2);
                Get.back();
              },
            ),
            _DrawerItem(
              icon: Icons.person_outline_rounded,
              label: 'Profile',
              onTap: () {
                shell.changeTab(3);
                Get.back();
              },
            ),
            const Spacer(),
            const Divider(color: AppColors.divider),
            const Padding(
              padding: EdgeInsets.all(20),
              child: Text(
                'v0.1.0',
                style: TextStyle(color: AppColors.textHint, fontSize: 12),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DrawerItem extends StatelessWidget {
  const _DrawerItem({
    required this.icon,
    required this.label,
    required this.onTap,
  });
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: AppColors.accent),
      title: Text(
        label,
        style: const TextStyle(
          color: AppColors.textPrimary,
          fontSize: 14,
          fontWeight: FontWeight.w600,
        ),
      ),
      onTap: onTap,
    );
  }
}

// ─── Bottom Navigation ────────────────────────────────────────────────────────
class _BottomNav extends StatelessWidget {
  const _BottomNav({required this.selected, required this.onTap});
  final int selected;
  final ValueChanged<int> onTap;

  @override
  Widget build(BuildContext context) {
    const items = [
      _NavItem(icon: Icons.home_rounded, label: 'Home'),
      _NavItem(icon: Icons.apartment_outlined, label: 'Properties'),
      _NavItem(icon: Icons.account_balance_wallet_outlined, label: 'My Bricks'),
      _NavItem(icon: Icons.person_outline_rounded, label: 'Profile'),
    ];
    return Container(
      height: 72,
      decoration: BoxDecoration(
        color: AppColors.white,
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withOpacity(0.08),
            blurRadius: 20,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: Row(
        children: List.generate(items.length, (i) {
          final active = i == selected;
          return Expanded(
            child: GestureDetector(
              onTap: () => onTap(i),
              behavior: HitTestBehavior.opaque,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (active)
                    Container(
                      width: 44,
                      height: 44,
                      decoration: const BoxDecoration(
                        color: AppColors.primary,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        items[i].icon,
                        color: AppColors.white,
                        size: 22,
                      ),
                    )
                  else
                    Icon(
                      items[i].icon,
                      color: AppColors.textSecondary,
                      size: 24,
                    ),
                  if (!active) ...[
                    const SizedBox(height: 4),
                    Text(
                      items[i].label,
                      style: const TextStyle(
                        color: AppColors.textPrimary,
                        fontSize: 10,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          );
        }),
      ),
    );
  }
}

class _NavItem {
  final IconData icon;
  final String label;
  const _NavItem({required this.icon, required this.label});
}
