import 'package:flutter/material.dart';

abstract final class AppColors {
  // Brand
  static const Color primary = Color(0xFF1A2340);
  static const Color accent = Color(0xFFD4A017);
  static const Color accentLight = Color(0xFFE8B84B);

  // Backgrounds
  static const Color background = Color(0xFFF8F9FF);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color surfaceVariant = Color(0xFFF0F2F8);

  // Text
  static const Color textPrimary = Color(0xFF1A2340);
  static const Color textSecondary = Color(0xFF6B7280);
  static const Color textHint = Color(0xFFADB5BD);

  // Input
  static const Color inputBackground = Color(0xFFF0F2F8);
  static const Color inputBorder = Color(0xFFE2E6F0);
  static const Color inputIcon = Color(0xFF9BA8C0);

  // Utility
  static const Color divider = Color(0xFFE8ECF4);
  static const Color error = Color(0xFFE53E3E);
  static const Color white = Color(0xFFFFFFFF);
}
