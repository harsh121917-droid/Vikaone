import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/investments_controller.dart';
import '../../../core/theme/app_colors.dart';
import '../../../data/models/grouped_investment.dart';
import '../../../routes/app_routes.dart';

class InvestmentsView extends GetView<InvestmentsController> {
  const InvestmentsView({super.key});

  String _fmt(int n) {
    if (n >= 10000000) return '₹${(n / 10000000).toStringAsFixed(2)}Cr';
    if (n >= 100000) return '₹${(n / 100000).toStringAsFixed(1)}L';
    return '₹$n';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.background,
      child: SafeArea(
        child: Obx(() {
          if (controller.isLoading.value) {
            return const Center(
              child: CircularProgressIndicator(color: AppColors.accent),
            );
          }
          if (controller.errorMsg.value.isNotEmpty) {
            return Center(
              child: Text(
                controller.errorMsg.value,
                style: const TextStyle(color: AppColors.textSecondary),
              ),
            );
          }
          if (controller.groupedHoldings.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      'My Bricks',
                      style: TextStyle(
                        color: AppColors.textPrimary,
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 24),
                    const Icon(
                      Icons.grid_view_rounded,
                      color: AppColors.inputIcon,
                      size: 64,
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'No investments yet',
                      style: TextStyle(
                        color: AppColors.textPrimary,
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Start owning fractions of luxury properties',
                      style: TextStyle(
                        color: AppColors.textSecondary,
                        fontSize: 13,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 20),
                    ElevatedButton(
                      onPressed: () => Get.toNamed(AppRoutes.properties),
                      child: const Text('Browse Properties'),
                    ),
                  ],
                ),
              ),
            );
          }

          return RefreshIndicator(
            onRefresh: controller.loadInvestments,
            color: AppColors.accent,
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                const Text(
                  'My Bricks',
                  style: TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 16),
                // Summary cards (based on raw transaction totals for accuracy)
                Row(
                  children: [
                    Expanded(
                      child: _SummaryCard(
                        label: 'Total Invested',
                        value: _fmt(controller.totalInvested),
                        color: AppColors.accent,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _SummaryCard(
                        label: 'Properties',
                        value: '${controller.propertyCount}',
                        color: const Color(0xFF3498db),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _SummaryCard(
                        label: 'Total Bricks',
                        value: '${controller.totalBricks}',
                        color: const Color(0xFF2ecc71),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),

                // One merged card per property
                ...controller.groupedHoldings.map(
                  (g) => _HoldingCard(holding: g),
                ),
              ],
            ),
          );
        }),
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({
    required this.label,
    required this.value,
    required this.color,
  });
  final String label, value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: AppColors.textSecondary,
              fontSize: 11,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            value,
            style: TextStyle(
              color: color,
              fontSize: 18,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}

class _HoldingCard extends StatelessWidget {
  const _HoldingCard({required this.holding});
  final GroupedInvestment holding;

  @override
  Widget build(BuildContext context) {
    final p = holding.property;
    final pct = holding.ownershipPercent;

    return GestureDetector(
      onTap: p != null
          ? () => Get.toNamed(AppRoutes.propertyDetail, arguments: p.id)
          : null,
      child: Container(
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(
          color: AppColors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: AppColors.primary.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(16),
              ),
              child: p?.coverImage != null
                  ? Image.network(
                      p!.coverImage!,
                      height: 120,
                      width: double.infinity,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => _placeholder(),
                    )
                  : _placeholder(),
            ),
            Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    p?.title ?? 'Property',
                    style: const TextStyle(
                      color: AppColors.textPrimary,
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    p?.location.city ?? 'India',
                    style: const TextStyle(
                      color: AppColors.textSecondary,
                      fontSize: 12,
                    ),
                  ),
                  const SizedBox(height: 12),
                  _StatRow(
                    label: 'Bricks Owned',
                    value: '${holding.bricks}',
                    valueColor: AppColors.accent,
                  ),
                  _StatRow(
                    label: 'Avg Price/Brick',
                    value: '₹${holding.avgPricePerBrick}',
                  ),
                  _StatRow(
                    label: 'Total Invested',
                    value: holding.formattedTotal,
                  ),
                  _StatRow(
                    label: 'Ownership',
                    value: '${pct.toStringAsFixed(2)}%',
                    valueColor: const Color(0xFF2ecc71),
                  ),
                  const SizedBox(height: 8),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: LinearProgressIndicator(
                      value: (pct / 100).clamp(0, 1),
                      backgroundColor: AppColors.inputBackground,
                      valueColor: const AlwaysStoppedAnimation<Color>(
                        AppColors.accent,
                      ),
                      minHeight: 6,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Last: ${holding.latestDate.day}/${holding.latestDate.month}/${holding.latestDate.year}',
                        style: const TextStyle(
                          color: AppColors.textSecondary,
                          fontSize: 11,
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: AppColors.accent.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          '${holding.transactionCount} TRANSACTION${holding.transactionCount > 1 ? "S" : ""}',
                          style: const TextStyle(
                            color: AppColors.accent,
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _placeholder() => Container(
    height: 120,
    color: AppColors.surfaceVariant,
    child: const Center(
      child: Icon(Icons.home_outlined, color: AppColors.inputIcon, size: 36),
    ),
  );
}

class _StatRow extends StatelessWidget {
  const _StatRow({required this.label, required this.value, this.valueColor});
  final String label, value;
  final Color? valueColor;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: AppColors.textSecondary,
              fontSize: 12,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              color: valueColor ?? AppColors.textPrimary,
              fontSize: 13,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}
