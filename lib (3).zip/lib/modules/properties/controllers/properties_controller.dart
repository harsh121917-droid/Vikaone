import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../../../data/models/property_model.dart';
import '../../../data/repositories/property_repository.dart';

class PropertiesController extends GetxController {
  final PropertyRepository _repo = Get.find();

  final isLoading = false.obs;
  final properties = <PropertyModel>[].obs;
  final errorMsg = ''.obs;
  final search = ''.obs;

  @override
  void onInit() {
    super.onInit();
    loadProperties();
  }

  Future<void> loadProperties() async {
    try {
      isLoading.value = true;
      errorMsg.value = '';
      properties.value = await _repo.getProperties(
        limit: 20,
        search: search.value.isEmpty ? null : search.value,
      );
    } on DioException catch (e) {
      errorMsg.value = e.response?.data?['message'] ?? 'Failed to load';
    } finally {
      isLoading.value = false;
    }
  }

  void onSearchChanged(String v) {
    search.value = v;
    loadProperties();
  }
}
