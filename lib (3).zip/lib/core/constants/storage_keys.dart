class StorageKeys {
  StorageKeys._();
  static const String token = 'bsqft_token';
  static const String user  = 'bsqft_user';
}
