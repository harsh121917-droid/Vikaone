import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import '../../../core/services/lock_service.dart';
import '../../../core/theme/app_colors.dart';
import '../../../routes/app_routes.dart';

// Called once after login/register to let user create a 4-digit passcode
class PasscodeSetupView extends StatefulWidget {
  const PasscodeSetupView({super.key});
  @override
  State<PasscodeSetupView> createState() => _PasscodeSetupViewState();
}

class _PasscodeSetupViewState extends State<PasscodeSetupView>
    with SingleTickerProviderStateMixin {
  // Phase: 0 = create, 1 = confirm
  int _phase = 0;
  String _first = '';
  String _input = '';
  bool _error = false;
  late final AnimationController _shake;
  late final Animation<double> _shakeAnim;

  @override
  void initState() {
    super.initState();
    _shake = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _shakeAnim = TweenSequence([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: -12.0), weight: 1),
      TweenSequenceItem(tween: Tween(begin: -12.0, end: 12.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 12.0, end: -8.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: -8.0, end: 8.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 8.0, end: 0.0), weight: 1),
    ]).animate(CurvedAnimation(parent: _shake, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _shake.dispose();
    super.dispose();
  }

  void _onKey(String k) {
    if (_input.length >= 4) return;
    HapticFeedback.selectionClick();
    setState(() {
      _input += k;
      _error = false;
    });
    if (_input.length == 4) _onComplete();
  }

  void _onDelete() {
    if (_input.isEmpty) return;
    HapticFeedback.lightImpact();
    setState(() => _input = _input.substring(0, _input.length - 1));
  }

  Future<void> _onComplete() async {
    await Future.delayed(const Duration(milliseconds: 200));
    if (_phase == 0) {
      setState(() {
        _first = _input;
        _input = '';
        _phase = 1;
      });
    } else {
      if (_input == _first) {
        HapticFeedback.mediumImpact();
        await LockService.to.savePasscode(_input);
        Get.offAllNamed(AppRoutes.home);
      } else {
        HapticFeedback.vibrate();
        setState(() {
          _error = true;
          _input = '';
        });
        _shake.forward(from: 0);
      }
    }
  }

  void _skip() => Get.offAllNamed(AppRoutes.home);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF060B16),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: _skip,
                    child: const Text(
                      'Skip for now',
                      style: TextStyle(color: Color(0xFF8A95B0), fontSize: 13),
                    ),
                  ),
                ],
              ),
              const Spacer(),

              // Lock icon
              Container(
                width: 72,
                height: 72,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    colors: [AppColors.accent, AppColors.accentLight],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.accent.withOpacity(0.4),
                      blurRadius: 20,
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.lock_outline_rounded,
                  color: Colors.white,
                  size: 34,
                ),
              ),
              const SizedBox(height: 24),

              Text(
                _phase == 0 ? 'Create Passcode' : 'Confirm Passcode',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                _phase == 0
                    ? 'Set a 4-digit PIN to secure your account'
                    : 'Enter your PIN again to confirm',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Color(0xFF8A95B0), fontSize: 14),
              ),
              const SizedBox(height: 36),

              // Dot indicators with shake
              AnimatedBuilder(
                animation: _shakeAnim,
                builder: (_, __) => Transform.translate(
                  offset: Offset(_shakeAnim.value, 0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(4, (i) {
                      final filled = i < _input.length;
                      return AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        margin: const EdgeInsets.symmetric(horizontal: 10),
                        width: filled ? 18 : 16,
                        height: filled ? 18 : 16,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _error
                              ? Colors.red
                              : filled
                              ? AppColors.accent
                              : Colors.white.withOpacity(0.15),
                          border: Border.all(
                            color: _error
                                ? Colors.red
                                : filled
                                ? AppColors.accent
                                : Colors.white.withOpacity(0.3),
                          ),
                          boxShadow: filled && !_error
                              ? [
                                  BoxShadow(
                                    color: AppColors.accent.withOpacity(0.5),
                                    blurRadius: 8,
                                  ),
                                ]
                              : null,
                        ),
                      );
                    }),
                  ),
                ),
              ),
              if (_error) ...[
                const SizedBox(height: 12),
                const Text(
                  'PINs do not match. Try again.',
                  style: TextStyle(
                    color: Colors.red,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],

              const Spacer(),

              // Numpad
              _NumPad(onKey: _onKey, onDelete: _onDelete),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Lock Screen ──────────────────────────────────────────────────────────────
// Shown every time app resumes if passcode is set
class LockScreenView extends StatefulWidget {
  const LockScreenView({super.key});
  @override
  State<LockScreenView> createState() => _LockScreenViewState();
}

class _LockScreenViewState extends State<LockScreenView>
    with SingleTickerProviderStateMixin {
  String _input = '';
  bool _error = false;
  late final AnimationController _shake;
  late final Animation<double> _shakeAnim;

  @override
  void initState() {
    super.initState();
    _shake = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _shakeAnim = TweenSequence([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: -12.0), weight: 1),
      TweenSequenceItem(tween: Tween(begin: -12.0, end: 12.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 12.0, end: -8.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: -8.0, end: 8.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 8.0, end: 0.0), weight: 1),
    ]).animate(CurvedAnimation(parent: _shake, curve: Curves.easeInOut));
    // Try biometric immediately on open
    WidgetsBinding.instance.addPostFrameCallback((_) => _tryBiometric());
  }

  @override
  void dispose() {
    _shake.dispose();
    super.dispose();
  }

  Future<void> _tryBiometric() async {
    if (!LockService.to.biometricEnabled) return;
    final ok = await LockService.to.authenticateWithBiometric();
    if (ok && mounted) _unlock();
  }

  void _onKey(String k) {
    if (_input.length >= 4) return;
    HapticFeedback.selectionClick();
    setState(() {
      _input += k;
      _error = false;
    });
    if (_input.length == 4) _onComplete();
  }

  void _onDelete() {
    if (_input.isEmpty) return;
    HapticFeedback.lightImpact();
    setState(() => _input = _input.substring(0, _input.length - 1));
  }

  Future<void> _onComplete() async {
    await Future.delayed(const Duration(milliseconds: 150));
    if (LockService.to.verifyPasscode(_input)) {
      HapticFeedback.mediumImpact();
      _unlock();
    } else {
      HapticFeedback.vibrate();
      setState(() {
        _error = true;
        _input = '';
      });
      _shake.forward(from: 0);
    }
  }

  void _unlock() => Get.offAllNamed(AppRoutes.home);

  @override
  Widget build(BuildContext context) {
    final canBiometric = LockService.to.biometricEnabled;

    return Scaffold(
      backgroundColor: const Color(0xFF060B16),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            children: [
              const Spacer(),

              // Gold lock icon
              Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    colors: [Color(0xFFB8860B), Color(0xFFFFD700)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFFFD700).withOpacity(0.4),
                      blurRadius: 24,
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.lock_rounded,
                  color: Colors.black,
                  size: 38,
                ),
              ),
              const SizedBox(height: 24),

              const Text(
                'Bharat SQFT',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -0.5,
                ),
              ),
              const SizedBox(height: 6),
              const Text(
                'Enter your PIN to continue',
                style: TextStyle(color: Color(0xFF8A95B0), fontSize: 14),
              ),
              const SizedBox(height: 36),

              // Dots
              AnimatedBuilder(
                animation: _shakeAnim,
                builder: (_, __) => Transform.translate(
                  offset: Offset(_shakeAnim.value, 0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(4, (i) {
                      final filled = i < _input.length;
                      return AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        margin: const EdgeInsets.symmetric(horizontal: 10),
                        width: filled ? 18 : 16,
                        height: filled ? 18 : 16,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _error
                              ? Colors.red
                              : filled
                              ? AppColors.accent
                              : Colors.white.withOpacity(0.15),
                          border: Border.all(
                            color: _error
                                ? Colors.red
                                : filled
                                ? AppColors.accent
                                : Colors.white.withOpacity(0.3),
                          ),
                          boxShadow: filled && !_error
                              ? [
                                  BoxShadow(
                                    color: AppColors.accent.withOpacity(0.5),
                                    blurRadius: 8,
                                  ),
                                ]
                              : null,
                        ),
                      );
                    }),
                  ),
                ),
              ),
              if (_error) ...[
                const SizedBox(height: 12),
                const Text(
                  'Incorrect PIN. Try again.',
                  style: TextStyle(
                    color: Colors.red,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],

              const Spacer(),

              // Numpad
              _NumPad(onKey: _onKey, onDelete: _onDelete),
              const SizedBox(height: 20),

              // Biometric button
              if (canBiometric)
                GestureDetector(
                  onTap: _tryBiometric,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 24,
                      vertical: 12,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.07),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: Colors.white.withOpacity(0.12)),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.fingerprint_rounded,
                          color: AppColors.accent,
                          size: 22,
                        ),
                        SizedBox(width: 8),
                        Text(
                          'Use biometric',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Shared Numpad ────────────────────────────────────────────────────────────
class _NumPad extends StatelessWidget {
  const _NumPad({required this.onKey, required this.onDelete});
  final ValueChanged<String> onKey;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    const keys = [
      ['1', '2', '3'],
      ['4', '5', '6'],
      ['7', '8', '9'],
      ['', '0', 'del'],
    ];
    return Column(
      children: keys
          .map(
            (row) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: row.map((k) {
                  if (k.isEmpty) return const SizedBox(width: 80, height: 70);
                  final isDel = k == 'del';
                  return GestureDetector(
                    onTap: () => isDel ? onDelete() : onKey(k),
                    child: Container(
                      width: 80,
                      height: 70,
                      margin: const EdgeInsets.symmetric(horizontal: 8),
                      decoration: BoxDecoration(
                        color: isDel
                            ? Colors.transparent
                            : Colors.white.withOpacity(0.06),
                        borderRadius: BorderRadius.circular(18),
                        border: isDel
                            ? null
                            : Border.all(color: Colors.white.withOpacity(0.1)),
                        boxShadow: isDel
                            ? null
                            : [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.2),
                                  blurRadius: 8,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                      ),
                      child: Center(
                        child: isDel
                            ? const Icon(
                                Icons.backspace_outlined,
                                color: Color(0xFF8A95B0),
                                size: 22,
                              )
                            : Text(
                                k,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 24,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
          )
          .toList(),
    );
  }
}
