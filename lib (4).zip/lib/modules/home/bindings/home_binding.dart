import 'package:get/get.dart';
import '../controllers/home_controller.dart';
import '../controllers/main_shell_controller.dart';
import '../../../data/repositories/property_repository.dart';
import '../../../data/repositories/investment_repository.dart';
import '../../../data/repositories/saving_repository.dart';
import '../../properties/controllers/properties_controller.dart';
import '../../investments/controllers/investments_controller.dart';
import '../../savings/controllers/savings_controller.dart';

class HomeBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<PropertyRepository>(() => PropertyRepository());
    Get.lazyPut<InvestmentRepository>(() => InvestmentRepository());
    Get.lazyPut<SavingRepository>(() => SavingRepository());

    Get.lazyPut<MainShellController>(() => MainShellController());
    Get.lazyPut<HomeController>(() => HomeController());
    Get.lazyPut<PropertiesController>(() => PropertiesController());
    Get.lazyPut<InvestmentsController>(() => InvestmentsController());
    Get.lazyPut<SavingsController>(() => SavingsController());
  }
}
