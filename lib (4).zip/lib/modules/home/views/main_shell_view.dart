import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../core/theme/app_colors.dart';
import '../../properties/views/properties_view.dart';
import '../../investments/views/investments_view.dart';
import '../views/home_view.dart';
import '../../profile/views/profile_view.dart';
import '../../savings/views/savings_view.dart';
import '../controllers/main_shell_controller.dart';
import '../../auth/controllers/auth_controller.dart';

class MainShellView extends GetView<MainShellController> {
  const MainShellView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const _AppDrawer(),
      body: Obx(
        () => IndexedStack(
          index: controller.tabIndex.value,
          children: const [
            HomeView(),
            PropertiesView(),
            InvestmentsView(),
            SavingsView(),
            ProfileView(),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Obx(
          () => _FloatingGlassNav(
            selected: controller.tabIndex.value,
            onTap: controller.changeTab,
          ),
        ),
      ),
    );
  }
}

// ─── Floating Glass Bottom Nav ─────────────────────────────────────────────────
class _FloatingGlassNav extends StatelessWidget {
  const _FloatingGlassNav({required this.selected, required this.onTap});
  final int selected;
  final ValueChanged<int> onTap;

  static const _items = [
    _NavItem(icon: Icons.home_rounded, label: 'Home'),
    _NavItem(icon: Icons.apartment_outlined, label: 'Properties'),
    _NavItem(icon: Icons.account_balance_wallet_outlined, label: 'My Bricks'),
    _NavItem(icon: Icons.savings_outlined, label: 'Savings'),
    _NavItem(icon: Icons.person_outline_rounded, label: 'Profile'),
  ];

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(30),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
          child: Container(
            height: 72,
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.88),
              borderRadius: BorderRadius.circular(30),
              border: Border.all(
                color: Colors.white.withOpacity(0.15),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: AppColors.primary.withOpacity(0.35),
                  blurRadius: 24,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Row(
              children: List.generate(_items.length, (i) {
                final active = i == selected;
                return Expanded(
                  child: GestureDetector(
                    onTap: () => onTap(i),
                    behavior: HitTestBehavior.opaque,
                    child: SizedBox(
                      height: 72,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          // Icon always same size — only decoration changes
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            width: 40,
                            height: 40,
                            decoration: active
                                ? BoxDecoration(
                                    gradient: const LinearGradient(
                                      colors: [
                                        AppColors.accent,
                                        AppColors.accentLight,
                                      ],
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                    ),
                                    shape: BoxShape.circle,
                                    boxShadow: [
                                      BoxShadow(
                                        color: AppColors.accent.withOpacity(
                                          0.5,
                                        ),
                                        blurRadius: 12,
                                        offset: const Offset(0, 4),
                                      ),
                                    ],
                                  )
                                : const BoxDecoration(
                                    color: Colors.transparent,
                                    shape: BoxShape.circle,
                                  ),
                            child: Icon(
                              _items[i].icon,
                              color: active
                                  ? Colors.white
                                  : Colors.white.withOpacity(0.45),
                              size: 20,
                            ),
                          ),
                          // Label always present — fades in/out (no layout shift)
                          const SizedBox(height: 3),
                          AnimatedOpacity(
                            duration: const Duration(milliseconds: 200),
                            opacity: active ? 0.0 : 1.0,
                            child: Text(
                              _items[i].label,
                              style: TextStyle(
                                color: active
                                    ? Colors.white
                                    : Colors.white.withOpacity(0.45),
                                fontSize: 9,
                                fontWeight: FontWeight.w500,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }),
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Drawer ───────────────────────────────────────────────────────────────────
class _AppDrawer extends StatelessWidget {
  const _AppDrawer();

  @override
  Widget build(BuildContext context) {
    final shell = Get.find<MainShellController>();
    return Drawer(
      backgroundColor: Colors.transparent,
      child: ClipRect(
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
          child: Container(
            color: Colors.white.withOpacity(0.92),
            child: SafeArea(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(24, 28, 24, 16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 48,
                          height: 48,
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [AppColors.primary, Color(0xFF2D4080)],
                            ),
                            borderRadius: BorderRadius.circular(14),
                            boxShadow: [
                              BoxShadow(
                                color: AppColors.primary.withOpacity(0.3),
                                blurRadius: 12,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: const Icon(
                            Icons.home_work_rounded,
                            color: Colors.white,
                            size: 26,
                          ),
                        ),
                        const SizedBox(height: 14),
                        const Text(
                          'Bharat SQFT',
                          style: TextStyle(
                            color: AppColors.textPrimary,
                            fontSize: 22,
                            fontWeight: FontWeight.w800,
                            letterSpacing: -0.5,
                          ),
                        ),
                        const Text(
                          'Find Your Dream Home',
                          style: TextStyle(
                            color: AppColors.textSecondary,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: 1,
                    color: AppColors.divider,
                    margin: const EdgeInsets.symmetric(horizontal: 20),
                  ),
                  const SizedBox(height: 12),
                  _DrawerItem(
                    icon: Icons.home_rounded,
                    label: 'Home',
                    onTap: () {
                      shell.changeTab(0);
                      Get.back();
                    },
                  ),
                  _DrawerItem(
                    icon: Icons.apartment_outlined,
                    label: 'Properties',
                    onTap: () {
                      shell.changeTab(1);
                      Get.back();
                    },
                  ),
                  _DrawerItem(
                    icon: Icons.grid_view_rounded,
                    label: 'My Bricks',
                    onTap: () {
                      shell.changeTab(2);
                      Get.back();
                    },
                  ),
                  _DrawerItem(
                    icon: Icons.savings_outlined,
                    label: 'Savings',
                    onTap: () {
                      shell.changeTab(3);
                      Get.back();
                    },
                  ),
                  _DrawerItem(
                    icon: Icons.person_outline_rounded,
                    label: 'Profile',
                    onTap: () {
                      shell.changeTab(4);
                      Get.back();
                    },
                  ),
                  const Spacer(),
                  Container(
                    height: 1,
                    color: AppColors.divider,
                    margin: const EdgeInsets.symmetric(horizontal: 20),
                  ),
                  const Padding(
                    padding: EdgeInsets.all(20),
                    child: Text(
                      'v0.1.0',
                      style: TextStyle(color: AppColors.textHint, fontSize: 12),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _DrawerItem extends StatelessWidget {
  const _DrawerItem({
    required this.icon,
    required this.label,
    required this.onTap,
  });
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => ListTile(
    leading: Container(
      width: 36,
      height: 36,
      decoration: BoxDecoration(
        color: AppColors.accent.withOpacity(0.1),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Icon(icon, color: AppColors.accent, size: 20),
    ),
    title: Text(
      label,
      style: const TextStyle(
        color: AppColors.textPrimary,
        fontSize: 14,
        fontWeight: FontWeight.w600,
      ),
    ),
    onTap: onTap,
    contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 2),
  );
}

class _NavItem {
  final IconData icon;
  final String label;
  const _NavItem({required this.icon, required this.label});
}
