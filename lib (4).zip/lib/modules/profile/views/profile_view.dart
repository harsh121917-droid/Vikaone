import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:real_estate/core/theme/controllers/theme_controller.dart';
import '../../../core/theme/app_colors.dart';
import '../../auth/controllers/auth_controller.dart';
import '../../../routes/app_routes.dart';

class ProfileView extends StatelessWidget {
  const ProfileView({super.key});

  @override
  Widget build(BuildContext context) {
    final authCtrl = Get.find<AuthController>();
    final theme = Get.find<ThemeController>();
    final cs = Theme.of(context).colorScheme;
    final isDark = theme.isDark.value;

    final bg = isDark ? DarkColors.background : AppColors.background;
    final cardBg = isDark ? DarkColors.surface : AppColors.white;
    final textP = isDark ? DarkColors.textPrimary : AppColors.textPrimary;
    final textS = isDark ? DarkColors.textSecondary : AppColors.textSecondary;
    final divCol = isDark ? DarkColors.divider : AppColors.divider;

    return Obx(() {
      final user = authCtrl.user.value;
      final dark = theme.isDark.value;

      return Container(
        color: dark ? DarkColors.background : AppColors.background,
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              // Header row
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Profile',
                    style: TextStyle(
                      color: dark
                          ? DarkColors.textPrimary
                          : AppColors.textPrimary,
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  // ── Theme toggle ──
                  GestureDetector(
                    onTap: theme.toggle,
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      width: 64,
                      height: 34,
                      padding: const EdgeInsets.all(3),
                      decoration: BoxDecoration(
                        color: dark
                            ? DarkColors.accent
                            : AppColors.primary.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(34),
                        border: Border.all(
                          color: dark
                              ? DarkColors.accent.withOpacity(0.4)
                              : AppColors.inputBorder,
                        ),
                      ),
                      child: Stack(
                        children: [
                          AnimatedAlign(
                            duration: const Duration(milliseconds: 260),
                            curve: Curves.easeOutCubic,
                            alignment: dark
                                ? Alignment.centerRight
                                : Alignment.centerLeft,
                            child: Container(
                              width: 26,
                              height: 26,
                              decoration: BoxDecoration(
                                color: dark ? Colors.black : AppColors.primary,
                                shape: BoxShape.circle,
                              ),
                              child: Icon(
                                dark
                                    ? Icons.dark_mode_rounded
                                    : Icons.light_mode_rounded,
                                color: dark ? DarkColors.accent : Colors.white,
                                size: 14,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),

              // Avatar + name
              Center(
                child: Column(
                  children: [
                    // Gold ring around avatar in dark mode
                    Container(
                      padding: dark ? const EdgeInsets.all(3) : EdgeInsets.zero,
                      decoration: dark
                          ? BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: const LinearGradient(
                                colors: [
                                  DarkColors.goldDark,
                                  DarkColors.goldLight,
                                  DarkColors.goldDark,
                                ],
                              ),
                            )
                          : null,
                      child: Container(
                        width: 84,
                        height: 84,
                        decoration: BoxDecoration(
                          color: dark ? DarkColors.surface : AppColors.accent,
                          shape: BoxShape.circle,
                          border: dark
                              ? Border.all(
                                  color: DarkColors.background,
                                  width: 2,
                                )
                              : null,
                        ),
                        child: Center(
                          child: Text(
                            (user?.name.isNotEmpty == true
                                    ? user!.name[0]
                                    : '?')
                                .toUpperCase(),
                            style: TextStyle(
                              color: dark ? DarkColors.accent : Colors.white,
                              fontSize: 32,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    Text(
                      user?.name ?? 'Guest',
                      style: TextStyle(
                        color: dark
                            ? DarkColors.textPrimary
                            : AppColors.textPrimary,
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      user?.email ?? '',
                      style: TextStyle(
                        color: dark
                            ? DarkColors.textSecondary
                            : AppColors.textSecondary,
                        fontSize: 13,
                      ),
                    ),
                    if (dark) ...[
                      const SizedBox(height: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: DarkColors.accent.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: DarkColors.accent.withOpacity(0.3),
                          ),
                        ),
                        child: const Text(
                          'INVESTOR',
                          style: TextStyle(
                            color: DarkColors.accent,
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 28),

              // Menu items
              _ProfileTile(
                icon: Icons.grid_view_rounded,
                label: 'My Bricks',
                onTap: () => Get.toNamed(AppRoutes.investments),
                dark: dark,
              ),
              _ProfileTile(
                icon: Icons.verified_user_outlined,
                label: 'KYC Verification',
                onTap: () => Get.toNamed(AppRoutes.kyc),
                dark: dark,
              ),
              _ProfileTile(
                icon: Icons.apartment_outlined,
                label: 'Browse Properties',
                onTap: () => Get.toNamed(AppRoutes.properties),
                dark: dark,
              ),
              _ProfileTile(
                icon: Icons.phone_outlined,
                label: 'Phone',
                trailing: user?.phone ?? '—',
                dark: dark,
              ),
              _ProfileTile(
                icon: Icons.badge_outlined,
                label: 'Account Type',
                trailing: (user?.role ?? 'user').toUpperCase(),
                dark: dark,
              ),

              const SizedBox(height: 24),

              // Logout
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () => authCtrl.logout(),
                  icon: const Icon(Icons.logout_rounded, color: Colors.red),
                  label: const Text(
                    'Logout',
                    style: TextStyle(
                      color: Colors.red,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size(double.infinity, 52),
                    side: const BorderSide(color: Colors.red),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    });
  }
}

class _ProfileTile extends StatelessWidget {
  const _ProfileTile({
    required this.icon,
    required this.label,
    required this.dark,
    this.trailing,
    this.onTap,
  });
  final IconData icon;
  final String label;
  final String? trailing;
  final VoidCallback? onTap;
  final bool dark;

  @override
  Widget build(BuildContext context) {
    final cardBg = dark ? DarkColors.surface : AppColors.white;
    final textP = dark ? DarkColors.textPrimary : AppColors.textPrimary;
    final textS = dark ? DarkColors.textSecondary : AppColors.textSecondary;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(14),
        border: dark ? Border.all(color: DarkColors.inputBorder) : null,
        boxShadow: dark
            ? null
            : [
                BoxShadow(
                  color: AppColors.primary.withOpacity(0.04),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
      ),
      child: ListTile(
        leading: Icon(icon, color: AppColors.accent),
        title: Text(
          label,
          style: TextStyle(
            color: textP,
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
        trailing: trailing != null
            ? Text(trailing!, style: TextStyle(color: textS, fontSize: 13))
            : (onTap != null
                  ? Icon(
                      Icons.chevron_right_rounded,
                      color: dark ? DarkColors.inputIcon : AppColors.inputIcon,
                    )
                  : null),
        onTap: onTap,
      ),
    );
  }
}
