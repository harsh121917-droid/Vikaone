import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:real_estate/core/theme/controllers/theme_controller.dart';
import '../controllers/investments_controller.dart';
import '../../../core/theme/app_colors.dart';
import '../../../data/models/grouped_investment.dart';
import '../../../routes/app_routes.dart';

class InvestmentsView extends GetView<InvestmentsController> {
  const InvestmentsView({super.key});

  String _fmt(int n) {
    if (n >= 10000000) return '₹${(n / 10000000).toStringAsFixed(2)}Cr';
    if (n >= 100000) return '₹${(n / 100000).toStringAsFixed(1)}L';
    return '₹$n';
  }

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final dark = Get.find<ThemeController>().isDark.value;
      final bg = dark ? DarkColors.background : AppColors.background;
      final textP = dark ? DarkColors.textPrimary : AppColors.textPrimary;
      final textS = dark ? DarkColors.textSecondary : AppColors.textSecondary;

      return Container(
        color: bg,
        child: SafeArea(
          child: Obx(() {
            if (controller.isLoading.value) {
              return Center(
                child: CircularProgressIndicator(color: AppColors.accent),
              );
            }
            if (controller.errorMsg.value.isNotEmpty) {
              return Center(
                child: Text(
                  controller.errorMsg.value,
                  style: TextStyle(color: textS),
                ),
              );
            }
            if (controller.groupedHoldings.isEmpty) {
              return Center(
                child: Padding(
                  padding: const EdgeInsets.all(32),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'My Bricks',
                        style: TextStyle(
                          color: textP,
                          fontSize: 22,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 24),
                      Icon(
                        Icons.grid_view_rounded,
                        color: dark
                            ? DarkColors.inputIcon
                            : AppColors.inputIcon,
                        size: 64,
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'No investments yet',
                        style: TextStyle(
                          color: textP,
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Start owning fractions of luxury properties',
                        style: TextStyle(color: textS, fontSize: 13),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 20),
                      ElevatedButton(
                        onPressed: () => Get.toNamed(AppRoutes.properties),
                        child: const Text('Browse Properties'),
                      ),
                    ],
                  ),
                ),
              );
            }

            return RefreshIndicator(
              onRefresh: controller.loadInvestments,
              color: AppColors.accent,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Text(
                    'My Bricks',
                    style: TextStyle(
                      color: textP,
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Summary cards
                  Row(
                    children: [
                      Expanded(
                        child: _SummaryCard(
                          label: 'Total Invested',
                          value: _fmt(controller.totalInvested),
                          color: AppColors.accent,
                          dark: dark,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _SummaryCard(
                          label: 'Properties',
                          value: '${controller.propertyCount}',
                          color: const Color(0xFF3498db),
                          dark: dark,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _SummaryCard(
                          label: 'Total Bricks',
                          value: '${controller.totalBricks}',
                          color: const Color(0xFF2ecc71),
                          dark: dark,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),

                  ...controller.groupedHoldings.map(
                    (g) => _HoldingCard(holding: g, dark: dark),
                  ),
                ],
              ),
            );
          }),
        ),
      );
    });
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({
    required this.label,
    required this.value,
    required this.color,
    required this.dark,
  });
  final String label, value;
  final Color color;
  final bool dark;

  @override
  Widget build(BuildContext context) {
    final cardBg = dark ? DarkColors.surface : AppColors.white;
    final textS = dark ? DarkColors.textSecondary : AppColors.textSecondary;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(14),
        border: dark ? Border.all(color: DarkColors.inputBorder) : null,
        boxShadow: dark
            ? null
            : [
                BoxShadow(
                  color: AppColors.primary.withOpacity(0.05),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
              color: textS,
              fontSize: 11,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            value,
            style: TextStyle(
              color: color,
              fontSize: 18,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}

class _HoldingCard extends StatelessWidget {
  const _HoldingCard({required this.holding, required this.dark});
  final GroupedInvestment holding;
  final bool dark;

  @override
  Widget build(BuildContext context) {
    final p = holding.property;
    final pct = holding.ownershipPercent;
    final cardBg = dark ? DarkColors.surface : AppColors.white;
    final textP = dark ? DarkColors.textPrimary : AppColors.textPrimary;
    final textS = dark ? DarkColors.textSecondary : AppColors.textSecondary;
    final inputBg = dark
        ? DarkColors.inputBackground
        : AppColors.inputBackground;

    return GestureDetector(
      onTap: p != null
          ? () => Get.toNamed(AppRoutes.propertyDetail, arguments: p.id)
          : null,
      child: Container(
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(
          color: cardBg,
          borderRadius: BorderRadius.circular(16),
          border: dark ? Border.all(color: DarkColors.inputBorder) : null,
          boxShadow: dark
              ? null
              : [
                  BoxShadow(
                    color: AppColors.primary.withOpacity(0.05),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Gold top stripe in dark mode
            if (dark)
              Container(
                height: 3,
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      DarkColors.goldDark,
                      DarkColors.goldLight,
                      DarkColors.goldDark,
                    ],
                  ),
                  borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
                ),
              ),
            ClipRRect(
              borderRadius: dark
                  ? BorderRadius.zero
                  : const BorderRadius.vertical(top: Radius.circular(16)),
              child: p?.coverImage != null
                  ? Image.network(
                      p!.coverImage!,
                      height: 120,
                      width: double.infinity,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => _placeholder(dark),
                    )
                  : _placeholder(dark),
            ),
            Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    p?.title ?? 'Property',
                    style: TextStyle(
                      color: textP,
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    p?.location.city ?? 'India',
                    style: TextStyle(color: textS, fontSize: 12),
                  ),
                  const SizedBox(height: 12),
                  _StatRow(
                    'Bricks Owned',
                    '${holding.bricks}',
                    AppColors.accent,
                    dark,
                  ),
                  _StatRow(
                    'Avg Price/Brick',
                    '₹${holding.avgPricePerBrick}',
                    null,
                    dark,
                  ),
                  _StatRow(
                    'Total Invested',
                    holding.formattedTotal,
                    null,
                    dark,
                  ),
                  _StatRow(
                    'Ownership',
                    '${pct.toStringAsFixed(2)}%',
                    const Color(0xFF2ecc71),
                    dark,
                  ),
                  const SizedBox(height: 8),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: LinearProgressIndicator(
                      value: (pct / 100).clamp(0, 1),
                      backgroundColor: inputBg,
                      valueColor: const AlwaysStoppedAnimation<Color>(
                        AppColors.accent,
                      ),
                      minHeight: 6,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Last: ${holding.latestDate.day}/${holding.latestDate.month}/${holding.latestDate.year}',
                        style: TextStyle(color: textS, fontSize: 11),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: AppColors.accent.withOpacity(dark ? 0.2 : 0.1),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          '${holding.transactionCount} TRANSACTION${holding.transactionCount > 1 ? "S" : ""}',
                          style: const TextStyle(
                            color: AppColors.accent,
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _placeholder(bool dark) => Container(
    height: 120,
    color: dark ? DarkColors.surfaceVariant : AppColors.surfaceVariant,
    child: Center(
      child: Icon(
        Icons.home_outlined,
        color: dark ? DarkColors.inputIcon : AppColors.inputIcon,
        size: 36,
      ),
    ),
  );
}

class _StatRow extends StatelessWidget {
  const _StatRow(this.label, this.value, this.valueColor, this.dark);
  final String label, value;
  final Color? valueColor;
  final bool dark;

  @override
  Widget build(BuildContext context) {
    final textP = dark ? DarkColors.textPrimary : AppColors.textPrimary;
    final textS = dark ? DarkColors.textSecondary : AppColors.textSecondary;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(color: textS, fontSize: 12)),
          Text(
            value,
            style: TextStyle(
              color: valueColor ?? textP,
              fontSize: 13,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}
