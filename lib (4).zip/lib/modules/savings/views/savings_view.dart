import 'dart:ui';
import 'dart:math';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import '../controllers/savings_controller.dart';
import '../../home/controllers/main_shell_controller.dart';
import '../../../core/theme/app_colors.dart';

// ─── Opportunity Model (placeholder cities) ──────────────────────────────────
class SavingOpportunity {
  final String city;
  final String tagline;
  final String code;
  final IconData icon;
  final List<Color> gradient;

  const SavingOpportunity({
    required this.city,
    required this.tagline,
    required this.code,
    required this.icon,
    required this.gradient,
  });
}

const _opportunities = [
  SavingOpportunity(
    city: 'Goa',
    tagline: 'Holiday Homes',
    code: 'GOHI',
    icon: Icons.beach_access_rounded,
    gradient: [Color(0xFFFF6B35), Color(0xFFFF8C5A)],
  ),
  SavingOpportunity(
    city: 'Bangalore',
    tagline: 'Prime Land',
    code: 'BPLD',
    icon: Icons.account_balance_rounded,
    gradient: [Color(0xFFFF6B35), Color(0xFFFFA557)],
  ),
  SavingOpportunity(
    city: 'Mumbai',
    tagline: 'Sky Residences',
    code: 'MSKY',
    icon: Icons.apartment_rounded,
    gradient: [Color(0xFFFF6B35), Color(0xFFFF9248)],
  ),
  SavingOpportunity(
    city: 'Pune',
    tagline: 'IT Hub Flats',
    code: 'PNIT',
    icon: Icons.business_rounded,
    gradient: [Color(0xFFFF6B35), Color(0xFFFF8240)],
  ),
];

class SavingsView extends GetView<SavingsController> {
  const SavingsView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFFEEF2FF), Color(0xFFF8F4FF), Color(0xFFFFF8F0)],
          ),
        ),
        child: SafeArea(
          child: Obx(() {
            if (controller.isLoading.value) {
              return const Center(
                child: CircularProgressIndicator(color: AppColors.accent),
              );
            }
            return Column(
              children: [
                const SizedBox(height: 8),
                _Header(),
                const SizedBox(height: 16),
                const Expanded(child: _SaveTabs()),
              ],
            );
          }),
        ),
      ),
    );
  }
}

// ─── Header ───────────────────────────────────────────────────────────────────
class _Header extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 20),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        const Text(
          'Save & Invest',
          style: TextStyle(
            color: AppColors.textPrimary,
            fontSize: 20,
            fontWeight: FontWeight.w800,
            letterSpacing: -0.5,
          ),
        ),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            GestureDetector(
              onTap: () => Get.find<SavingsController>().goToMyPlans(),
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 7,
                ),
                decoration: BoxDecoration(
                  color: AppColors.primary.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: const [
                    Icon(
                      Icons.savings_outlined,
                      color: AppColors.primary,
                      size: 14,
                    ),
                    SizedBox(width: 4),
                    Text(
                      'My Plans',
                      style: TextStyle(
                        color: AppColors.primary,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 8),
            // ℹ icon only — saves space, same tap = how it works sheet
            GestureDetector(
              onTap: () => _showHowItWorks(context),
              child: Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: AppColors.accent.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.info_outline_rounded,
                  color: AppColors.accent,
                  size: 18,
                ),
              ),
            ),
          ],
        ),
      ],
    ),
  );

  void _showHowItWorks(BuildContext context) {
    Get.bottomSheet(
      Container(
        padding: const EdgeInsets.all(24),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: AppColors.inputBorder,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 18),
            const Text(
              'How saving works',
              style: TextStyle(
                color: AppColors.textPrimary,
                fontSize: 18,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 14),
            ...[
              ('1', 'Daily: pick a daily auto-save amount and watch it grow'),
              (
                '2',
                'Monthly: pick a city opportunity, sqft per month & tenure',
              ),
              ('3', 'We auto-debit and convert savings into sqft ownership'),
              ('4', 'Track everything in your Portfolio anytime'),
            ].map(
              (s) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 24,
                      height: 24,
                      decoration: const BoxDecoration(
                        color: AppColors.accent,
                        shape: BoxShape.circle,
                      ),
                      child: Center(
                        child: Text(
                          s.$1,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        s.$2,
                        style: const TextStyle(
                          color: AppColors.textSecondary,
                          fontSize: 13,
                          height: 1.4,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      isScrollControlled: true,
    );
  }
}

// ─── Tabs Wrapper ─────────────────────────────────────────────────────────────
class _SaveTabs extends StatefulWidget {
  const _SaveTabs();
  @override
  State<_SaveTabs> createState() => _SaveTabsState();
}

class _SaveTabsState extends State<_SaveTabs> {
  int _tab = 0; // 0 = daily, 1 = monthly
  Timer? _timer;

  static const _rotateEvery = Duration(seconds: 6);

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(_rotateEvery, (_) {
      if (!mounted) return;
      // don't yank the user away while a dialog or bottom sheet is open
      if ((Get.isDialogOpen ?? false) || (Get.isBottomSheetOpen ?? false))
        return;
      setState(() => _tab = _tab == 0 ? 1 : 0);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: _AutoModeLabel(selected: _tab),
        ),
        const SizedBox(height: 18),
        Expanded(
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 450),
            transitionBuilder: (child, anim) => FadeTransition(
              opacity: anim,
              child: SlideTransition(
                position: Tween(begin: const Offset(0, 0.06), end: Offset.zero)
                    .animate(
                      CurvedAnimation(parent: anim, curve: Curves.easeOutCubic),
                    ),
                child: child,
              ),
            ),
            child: _tab == 0
                ? const _DailyPlanSection(key: ValueKey('daily'))
                : const _MonthlyOpportunitySection(key: ValueKey('monthly')),
          ),
        ),
      ],
    );
  }
}

// ─── Auto Mode Label (no tap — just shows which section + progress dots) ─────
class _AutoModeLabel extends StatelessWidget {
  const _AutoModeLabel({required this.selected});
  final int selected; // 0 = daily, 1 = monthly

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 52,
      padding: const EdgeInsets.symmetric(horizontal: 18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: AppColors.inputBorder),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 300),
            transitionBuilder: (child, anim) => FadeTransition(
              opacity: anim,
              child: SlideTransition(
                position: Tween(
                  begin: const Offset(0, 0.3),
                  end: Offset.zero,
                ).animate(anim),
                child: child,
              ),
            ),
            child: Row(
              key: ValueKey(selected),
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  selected == 0
                      ? Icons.wb_sunny_outlined
                      : Icons.calendar_month_outlined,
                  color: AppColors.accent,
                  size: 18,
                ),
                const SizedBox(width: 8),
                Text(
                  selected == 0 ? 'Daily Saving Plan' : 'Monthly Investment',
                  style: const TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          // progress dots showing auto-rotation
          Row(
            mainAxisSize: MainAxisSize.min,
            children: List.generate(2, (i) {
              final active = i == selected;
              return AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                margin: const EdgeInsets.symmetric(horizontal: 3),
                width: active ? 18 : 6,
                height: 6,
                decoration: BoxDecoration(
                  color: active ? AppColors.accent : AppColors.inputBorder,
                  borderRadius: BorderRadius.circular(3),
                ),
              );
            }),
          ),
        ],
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
// ─── DAILY SECTION — growth chart + rate hike + daily plan chips ─────────────
// ════════════════════════════════════════════════════════════════════════════
class _DailyPlanSection extends StatefulWidget {
  const _DailyPlanSection({super.key});
  @override
  State<_DailyPlanSection> createState() => _DailyPlanSectionState();
}

class _DailyPlanSectionState extends State<_DailyPlanSection> {
  int _amount = 50;
  int _tenureYears = 3;
  bool _agreed = false;

  static const _chips = [10, 50, 100, 250];

  int get _projectedTotal {
    final totalCycles = 365 * _tenureYears;
    final principal = _amount * totalCycles;
    const rate = 0.11; // annualised rate hike
    final years = _tenureYears.toDouble();
    return (principal * pow(1 + rate, years / 2)).round();
  }

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<SavingsController>();

    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 40),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _ProjectionCard(
            tenureYears: _tenureYears,
            projectedTotal: _projectedTotal,
          ),
          const SizedBox(height: 10),

          Row(
            children: [1, 3, 5, 7].map((y) {
              final active = y == _tenureYears;
              return Expanded(
                child: GestureDetector(
                  onTap: () {
                    HapticFeedback.selectionClick();
                    setState(() => _tenureYears = y);
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    margin: const EdgeInsets.symmetric(horizontal: 3),
                    padding: const EdgeInsets.symmetric(vertical: 9),
                    decoration: BoxDecoration(
                      color: active ? AppColors.primary : Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: active
                            ? Colors.transparent
                            : AppColors.inputBorder,
                      ),
                    ),
                    child: Text(
                      '$y Yr',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: active ? Colors.white : AppColors.textSecondary,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 24),

          const Text(
            'Choose Your Daily Saving Amount',
            style: TextStyle(
              color: AppColors.textPrimary,
              fontSize: 15,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 12),
          _AmountChips(
            chips: _chips,
            selected: _amount,
            onSelect: (v) => setState(() => _amount = v),
          ),
          const SizedBox(height: 10),

          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: AppColors.accent.withOpacity(0.08),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.accent.withOpacity(0.2)),
            ),
            child: Row(
              children: [
                const Icon(
                  Icons.celebration_outlined,
                  color: AppColors.accent,
                  size: 16,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: RichText(
                    text: const TextSpan(
                      style: TextStyle(
                        color: AppColors.textSecondary,
                        fontSize: 12,
                      ),
                      children: [
                        TextSpan(text: 'Get '),
                        TextSpan(
                          text: '10% cashback',
                          style: TextStyle(
                            color: AppColors.accent,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        TextSpan(text: ' on your first auto-debit'),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 22),

          const Text(
            '*Returns and liquidity are not guaranteed and are subjected to market risks.',
            style: TextStyle(
              color: AppColors.textHint,
              fontSize: 10.5,
              height: 1.4,
            ),
          ),
          const SizedBox(height: 16),

          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                width: 22,
                height: 22,
                child: Checkbox(
                  value: _agreed,
                  onChanged: (v) => setState(() => _agreed = v ?? false),
                  activeColor: AppColors.accent,
                  materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: RichText(
                  text: const TextSpan(
                    style: TextStyle(
                      color: AppColors.textSecondary,
                      fontSize: 12,
                      height: 1.4,
                    ),
                    children: [
                      TextSpan(
                        text:
                            'I agree to digitally execute & be legally bound by this ',
                      ),
                      TextSpan(
                        text: 'Purchase Agreement',
                        style: TextStyle(
                          color: AppColors.accent,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),

          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _agreed
                  ? () async {
                      HapticFeedback.mediumImpact();
                      final ok = await controller.createPlan(
                        type: 'daily',
                        targetAmount: _projectedTotal,
                        amountPerCycle: _amount,
                      );
                      if (ok && context.mounted) {
                        _showSuccessAnim(
                          context,
                          planType: 'daily',
                          amount: _amount,
                        );
                      }
                    }
                  : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.accent,
                disabledBackgroundColor: AppColors.inputBackground,
                foregroundColor: Colors.white,
                minimumSize: const Size(double.infinity, 54),
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              child: const Text(
                'Start Daily Plan',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
// ─── MONTHLY SECTION — investment opportunity + sqft + tenure + IRR ─────────
// ════════════════════════════════════════════════════════════════════════════
class _MonthlyOpportunitySection extends StatefulWidget {
  const _MonthlyOpportunitySection({super.key});
  @override
  State<_MonthlyOpportunitySection> createState() =>
      _MonthlyOpportunitySectionState();
}

class _MonthlyOpportunitySectionState
    extends State<_MonthlyOpportunitySection> {
  int _opportunityIndex = 0;
  int _sqftPerMonth = 3; // range 3 - 5
  int _tenureYears = 1;
  bool _agreed = false;
  final _pageCtrl = PageController(viewportFraction: 0.86);

  static const int _pricePerSqft = 750;

  int get _monthlySavings => _sqftPerMonth * _pricePerSqft;

  int get _totalSavings {
    final months = 12 * _tenureYears;
    final principal = _monthlySavings * months;
    const rate = 0.11;
    final years = _tenureYears.toDouble();
    return (principal * pow(1 + rate, years / 2)).round();
  }

  int get _totalSqft => _sqftPerMonth * 12 * _tenureYears;

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<SavingsController>();
    final opp = _opportunities[_opportunityIndex];

    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 40),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Select any 1 investment opportunity',
            style: TextStyle(
              color: AppColors.accent,
              fontSize: 13,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 190,
            child: PageView.builder(
              controller: _pageCtrl,
              itemCount: _opportunities.length,
              onPageChanged: (i) => setState(() => _opportunityIndex = i),
              itemBuilder: (_, i) => _OpportunityCard(
                opp: _opportunities[i],
                active: i == _opportunityIndex,
              ),
            ),
          ),
          const SizedBox(height: 10),
          Center(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: List.generate(_opportunities.length, (i) {
                final active = i == _opportunityIndex;
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  width: active ? 18 : 6,
                  height: 6,
                  decoration: BoxDecoration(
                    color: active ? AppColors.accent : AppColors.inputBorder,
                    borderRadius: BorderRadius.circular(3),
                  ),
                );
              }),
            ),
          ),
          const SizedBox(height: 22),

          _InfoRow(
            label: 'Opportunity Name',
            value: opp.code,
            valueColor: AppColors.accent,
          ),
          const SizedBox(height: 10),

          _StepperRow(
            label: 'SQFT Per Month',
            value: _sqftPerMonth,
            onMinus: () => setState(() {
              if (_sqftPerMonth > 3) _sqftPerMonth--;
            }),
            onPlus: () => setState(() {
              if (_sqftPerMonth < 5) _sqftPerMonth++;
            }),
          ),
          const SizedBox(height: 10),

          _StepperRow(
            label: 'Tenure',
            value: _tenureYears,
            valueLabel: '$_tenureYears Year${_tenureYears > 1 ? 's' : ''}',
            onMinus: () => setState(() {
              if (_tenureYears > 1) _tenureYears--;
            }),
            onPlus: () => setState(() {
              if (_tenureYears < 10) _tenureYears++;
            }),
          ),
          const SizedBox(height: 16),

          _SummaryDetailsCard(
            totalSqft: _totalSqft,
            monthlySavings: _monthlySavings,
            totalSavings: _totalSavings,
          ),
          const SizedBox(height: 14),

          const Text(
            '*Returns and liquidity are not guaranteed and are subjected to market risks.',
            style: TextStyle(
              color: AppColors.textHint,
              fontSize: 10.5,
              height: 1.4,
            ),
          ),
          const SizedBox(height: 16),

          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                width: 22,
                height: 22,
                child: Checkbox(
                  value: _agreed,
                  onChanged: (v) => setState(() => _agreed = v ?? false),
                  activeColor: AppColors.accent,
                  materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: RichText(
                  text: const TextSpan(
                    style: TextStyle(
                      color: AppColors.textSecondary,
                      fontSize: 12,
                      height: 1.4,
                    ),
                    children: [
                      TextSpan(
                        text:
                            'I agree to digitally execute & be legally bound by this ',
                      ),
                      TextSpan(
                        text: 'Purchase Agreement',
                        style: TextStyle(
                          color: AppColors.accent,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),

          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _agreed
                  ? () async {
                      HapticFeedback.mediumImpact();
                      final ok = await controller.createPlan(
                        type: 'monthly',
                        targetAmount: _totalSavings,
                        amountPerCycle: _monthlySavings,
                      );
                      if (ok && context.mounted) {
                        _showSuccessAnim(
                          context,
                          planType: 'monthly',
                          amount: _monthlySavings,
                        );
                      }
                    }
                  : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.accent,
                disabledBackgroundColor: AppColors.inputBackground,
                foregroundColor: Colors.white,
                minimumSize: const Size(double.infinity, 54),
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              child: const Text(
                'Invest Now',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
              ),
            ),
          ),
          const SizedBox(height: 28),

          const Text(
            'Potential IRR Calculator',
            style: TextStyle(
              color: AppColors.textPrimary,
              fontSize: 15,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 14),
          _IRRCalculator(principal: _monthlySavings * 12 * _tenureYears),
        ],
      ),
    );
  }
}

// ─── Shared success popup trigger ─────────────────────────────────────────────
void _showSuccessAnim(
  BuildContext context, {
  required String planType,
  required int amount,
}) {
  Get.dialog(
    _SuccessOverlay(planType: planType, amount: amount),
    barrierDismissible: true,
    barrierColor: Colors.black54,
  );
}

// ─── Projection Card (animated growth chart, daily only) ─────────────────────
class _ProjectionCard extends StatefulWidget {
  const _ProjectionCard({
    required this.tenureYears,
    required this.projectedTotal,
  });
  final int tenureYears, projectedTotal;

  @override
  State<_ProjectionCard> createState() => _ProjectionCardState();
}

class _ProjectionCardState extends State<_ProjectionCard> {
  late int _displayedTotal;

  @override
  void initState() {
    super.initState();
    _displayedTotal = widget.projectedTotal;
  }

  @override
  void didUpdateWidget(covariant _ProjectionCard old) {
    super.didUpdateWidget(old);
    // animate FROM the previously shown total TO the new one
    if (old.projectedTotal != widget.projectedTotal) {
      _displayedTotal = old.projectedTotal;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 22, 20, 16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AppColors.primary, Color(0xFF1A2340)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withOpacity(0.3),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text(
                'Saving in',
                style: TextStyle(color: Colors.white70, fontSize: 13),
              ),
              const SizedBox(width: 6),
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 250),
                transitionBuilder: (child, anim) => FadeTransition(
                  opacity: anim,
                  child: SlideTransition(
                    position: Tween(
                      begin: const Offset(0, 0.4),
                      end: Offset.zero,
                    ).animate(anim),
                    child: child,
                  ),
                ),
                child: Text(
                  '${widget.tenureYears} Year${widget.tenureYears > 1 ? 's' : ''}',
                  key: ValueKey(widget.tenureYears),
                  style: const TextStyle(
                    color: AppColors.accent,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          TweenAnimationBuilder<double>(
            key: ValueKey('amount_${widget.projectedTotal}'),
            tween: Tween(
              begin: _displayedTotal.toDouble(),
              end: widget.projectedTotal.toDouble(),
            ),
            duration: const Duration(milliseconds: 650),
            curve: Curves.easeOutCubic,
            builder: (_, value, __) => Text(
              '₹${value.round().toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]},')}',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 32,
                fontWeight: FontWeight.w800,
                letterSpacing: -0.5,
              ),
            ),
          ),
          const SizedBox(height: 18),
          SizedBox(
            height: 110,
            child: TweenAnimationBuilder<double>(
              key: ValueKey(
                'chart_${widget.tenureYears}_${widget.projectedTotal}',
              ),
              tween: Tween(begin: 0, end: 1),
              duration: const Duration(milliseconds: 900),
              curve: Curves.easeOutCubic,
              builder: (_, t, __) => CustomPaint(
                size: Size.infinite,
                painter: _GrowthChartPainter(progress: t),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _GrowthChartPainter extends CustomPainter {
  _GrowthChartPainter({required this.progress});
  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    const n = 5;
    final points = <Offset>[];
    for (int i = 0; i <= n; i++) {
      final x = size.width * (i / n);
      final t = i / n;
      final y = size.height * (1 - (0.12 + 0.85 * pow(t, 1.4)));
      points.add(Offset(x, y.clamp(0, size.height)));
    }

    final visiblePoints = (points.length * progress)
        .clamp(1, points.length)
        .toInt();
    final path = Path();
    for (int i = 0; i < visiblePoints; i++) {
      if (i == 0) {
        path.moveTo(points[i].dx, points[i].dy);
      } else {
        final prev = points[i - 1];
        final curr = points[i];
        final mid = Offset((prev.dx + curr.dx) / 2, (prev.dy + curr.dy) / 2);
        path.quadraticBezierTo(prev.dx, prev.dy, mid.dx, mid.dy);
        if (i == visiblePoints - 1) path.lineTo(curr.dx, curr.dy);
      }
    }

    final fillPath = Path.from(path)
      ..lineTo(points[visiblePoints - 1].dx, size.height)
      ..lineTo(points[0].dx, size.height)
      ..close();

    canvas.drawPath(
      fillPath,
      Paint()
        ..shader = LinearGradient(
          colors: [
            const Color(0xFFFF6B35).withOpacity(0.25),
            Colors.transparent,
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ).createShader(Rect.fromLTWH(0, 0, size.width, size.height)),
    );

    canvas.drawPath(
      path,
      Paint()
        ..color = const Color(0xFFFF6B35)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..strokeCap = StrokeCap.round,
    );

    for (int i = 0; i < visiblePoints; i++) {
      canvas.drawCircle(points[i], 4, Paint()..color = const Color(0xFFFF6B35));
      canvas.drawCircle(
        points[i],
        7,
        Paint()..color = const Color(0xFFFF6B35).withOpacity(0.25),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _GrowthChartPainter old) =>
      old.progress != progress;
}

// ─── Amount Chips (daily) ──────────────────────────────────────────────────────
class _AmountChips extends StatelessWidget {
  const _AmountChips({
    required this.chips,
    required this.selected,
    required this.onSelect,
  });
  final List<int> chips;
  final int selected;
  final ValueChanged<int> onSelect;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: chips.map((c) {
        final active = c == selected;
        return Expanded(
          child: GestureDetector(
            onTap: () {
              HapticFeedback.selectionClick();
              onSelect(c);
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.symmetric(horizontal: 4),
              padding: const EdgeInsets.symmetric(vertical: 13),
              decoration: BoxDecoration(
                gradient: active
                    ? const LinearGradient(
                        colors: [AppColors.accent, AppColors.accentLight],
                      )
                    : null,
                color: active ? null : Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: active ? Colors.transparent : AppColors.inputBorder,
                ),
                boxShadow: active
                    ? [
                        BoxShadow(
                          color: AppColors.accent.withOpacity(0.3),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ]
                    : null,
              ),
              child: Text(
                '₹$c',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: active ? Colors.white : AppColors.textPrimary,
                  fontSize: 14,
                  fontWeight: active ? FontWeight.w700 : FontWeight.w600,
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

// ─── Opportunity Carousel Card (monthly) ──────────────────────────────────────
class _OpportunityCard extends StatelessWidget {
  const _OpportunityCard({required this.opp, required this.active});
  final SavingOpportunity opp;
  final bool active;

  @override
  Widget build(BuildContext context) {
    return AnimatedScale(
      scale: active ? 1.0 : 0.93,
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOut,
      child: AnimatedOpacity(
        opacity: active ? 1.0 : 0.55,
        duration: const Duration(milliseconds: 250),
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 6),
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                opp.gradient[0].withOpacity(0.85),
                const Color(0xFF1A1410),
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(
                color: opp.gradient[0].withOpacity(0.25),
                blurRadius: 16,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                'Invest in Your Favorite City',
                style: TextStyle(
                  color: Colors.white.withOpacity(0.85),
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                opp.city,
                style: const TextStyle(
                  color: AppColors.accent,
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 8),
              Icon(opp.icon, color: Colors.white, size: 48),
              const SizedBox(height: 8),
              Text(
                opp.tagline,
                style: const TextStyle(
                  color: AppColors.accent,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Info Row ─────────────────────────────────────────────────────────────────
class _InfoRow extends StatelessWidget {
  const _InfoRow({required this.label, required this.value, this.valueColor});
  final String label, value;
  final Color? valueColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.inputBorder),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: AppColors.textSecondary,
              fontSize: 14,
            ),
          ),
          Row(
            children: [
              Text(
                value,
                style: TextStyle(
                  color: valueColor ?? AppColors.textPrimary,
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(width: 6),
              const Icon(
                Icons.info_outline_rounded,
                color: AppColors.inputIcon,
                size: 15,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ─── Stepper Row ──────────────────────────────────────────────────────────────
class _StepperRow extends StatelessWidget {
  const _StepperRow({
    required this.label,
    required this.value,
    required this.onMinus,
    required this.onPlus,
    this.valueLabel,
  });
  final String label;
  final int value;
  final String? valueLabel;
  final VoidCallback onMinus, onPlus;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.inputBorder),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: AppColors.textSecondary,
              fontSize: 14,
            ),
          ),
          Row(
            children: [
              _StepBtn(icon: Icons.remove_rounded, onTap: onMinus),
              SizedBox(
                width: 64,
                child: Text(
                  valueLabel ?? '$value',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: AppColors.accent,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              _StepBtn(icon: Icons.add_rounded, onTap: onPlus),
            ],
          ),
        ],
      ),
    );
  }
}

class _StepBtn extends StatelessWidget {
  const _StepBtn({required this.icon, required this.onTap});
  final IconData icon;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: () {
      HapticFeedback.selectionClick();
      onTap();
    },
    child: Container(
      width: 30,
      height: 30,
      decoration: BoxDecoration(
        color: AppColors.surfaceVariant,
        shape: BoxShape.circle,
      ),
      child: Icon(icon, color: AppColors.textSecondary, size: 16),
    ),
  );
}

// ─── Summary Details Card (monthly) ───────────────────────────────────────────
class _SummaryDetailsCard extends StatelessWidget {
  const _SummaryDetailsCard({
    required this.totalSqft,
    required this.monthlySavings,
    required this.totalSavings,
  });
  final int totalSqft, monthlySavings, totalSavings;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withOpacity(0.06),
            blurRadius: 14,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        children: [
          _SummaryLine(label: 'Total SQFT', value: '$totalSqft'),
          const Divider(height: 20),
          _SummaryLine(
            label: 'Monthly Savings',
            value: '₹${_fmt(monthlySavings)}',
          ),
          const Divider(height: 20),
          _SummaryLine(
            label: 'Total Savings',
            value: '₹${_fmt(totalSavings)}',
            big: true,
          ),
        ],
      ),
    );
  }

  String _fmt(int n) => n.toString().replaceAllMapped(
    RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'),
    (m) => '${m[1]},',
  );
}

class _SummaryLine extends StatelessWidget {
  const _SummaryLine({
    required this.label,
    required this.value,
    this.big = false,
  });
  final String label, value;
  final bool big;
  @override
  Widget build(BuildContext context) => Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Text(
        label,
        style: const TextStyle(color: AppColors.textSecondary, fontSize: 14),
      ),
      Text(
        value,
        style: TextStyle(
          color: AppColors.accent,
          fontSize: big ? 18 : 15,
          fontWeight: FontWeight.w800,
        ),
      ),
    ],
  );
}

// ─── IRR Calculator (monthly only) ─────────────────────────────────────────────
class _IRRCalculator extends StatefulWidget {
  const _IRRCalculator({required this.principal});
  final int principal;

  @override
  State<_IRRCalculator> createState() => _IRRCalculatorState();
}

class _IRRCalculatorState extends State<_IRRCalculator> {
  double _irr = 11;

  @override
  Widget build(BuildContext context) {
    final futureValue = (widget.principal * pow(1 + _irr / 100, 3)).round();

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withOpacity(0.06),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Align(
            alignment: Alignment.centerRight,
            child: TweenAnimationBuilder<double>(
              tween: Tween(begin: 0, end: _irr),
              duration: const Duration(milliseconds: 400),
              builder: (_, v, __) => Text(
                '${v.toStringAsFixed(0)}%',
                style: const TextStyle(
                  color: AppColors.primary,
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            height: 70,
            child: LayoutBuilder(
              builder: (_, c) {
                const barCount = 36;
                final activeBars = ((_irr / 20) * barCount).round();
                return Row(
                  children: List.generate(barCount, (i) {
                    final active = i < activeBars;
                    final h = 18.0 + (i % 5) * 9.0;
                    return Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 1),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 250),
                          height: h.clamp(18, 64),
                          decoration: BoxDecoration(
                            color: active
                                ? AppColors.accent
                                : AppColors.inputBorder,
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                      ),
                    );
                  }),
                );
              },
            ),
          ),
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              activeTrackColor: AppColors.accent,
              inactiveTrackColor: AppColors.inputBorder,
              thumbColor: Colors.white,
              thumbShape: const RoundSliderThumbShape(
                enabledThumbRadius: 9,
                elevation: 3,
              ),
              overlayColor: AppColors.accent.withOpacity(0.15),
              trackHeight: 3,
            ),
            child: Slider(
              value: _irr,
              min: 5,
              max: 20,
              onChanged: (v) {
                HapticFeedback.selectionClick();
                setState(() => _irr = v);
              },
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: const [
              Text(
                '5%',
                style: TextStyle(color: AppColors.textHint, fontSize: 11),
              ),
              Text(
                '20%',
                style: TextStyle(color: AppColors.textHint, fontSize: 11),
              ),
            ],
          ),
          const SizedBox(height: 14),
          _IRRRow(label: 'Suggested Holding Period', value: '3 year'),
          const SizedBox(height: 10),
          _IRRRow(
            label: 'Potential Future Value',
            value: '₹${_fmt(futureValue)}',
          ),
        ],
      ),
    );
  }

  String _fmt(int n) => n.toString().replaceAllMapped(
    RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'),
    (m) => '${m[1]},',
  );
}

class _IRRRow extends StatelessWidget {
  const _IRRRow({required this.label, required this.value});
  final String label, value;
  @override
  Widget build(BuildContext context) => Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Row(
        children: [
          Text(
            label,
            style: const TextStyle(
              color: AppColors.textSecondary,
              fontSize: 13,
            ),
          ),
          const SizedBox(width: 4),
          const Icon(
            Icons.info_outline_rounded,
            color: AppColors.inputIcon,
            size: 13,
          ),
        ],
      ),
      Text(
        value,
        style: const TextStyle(
          color: AppColors.primary,
          fontSize: 14,
          fontWeight: FontWeight.w700,
        ),
      ),
    ],
  );
}

// ─── Success Overlay (confirmation card, not just a checkmark) ───────────────
class _SuccessOverlay extends StatefulWidget {
  const _SuccessOverlay({required this.planType, required this.amount});
  final String planType; // 'daily' | 'monthly'
  final int amount;

  @override
  State<_SuccessOverlay> createState() => _SuccessOverlayState();
}

class _SuccessOverlayState extends State<_SuccessOverlay>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _scale = CurvedAnimation(parent: _ctrl, curve: Curves.elasticOut);
    _ctrl.forward();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDaily = widget.planType == 'daily';
    return Center(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 32),
        padding: const EdgeInsets.fromLTRB(28, 32, 28, 24),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(28),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 30,
              offset: const Offset(0, 12),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ScaleTransition(
              scale: _scale,
              child: Container(
                width: 84,
                height: 84,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF2ecc71), Color(0xFF27ae60)],
                  ),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF2ecc71).withOpacity(0.45),
                      blurRadius: 24,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.check_rounded,
                  color: Colors.white,
                  size: 44,
                ),
              ),
            ),
            const SizedBox(height: 18),
            Text(
              isDaily ? 'Daily Plan Started!' : 'Investment Created!',
              style: const TextStyle(
                color: AppColors.textPrimary,
                fontSize: 18,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              isDaily
                  ? 'Saving ₹${widget.amount} every day. Track progress anytime in My Bricks.'
                  : 'Saving ₹${widget.amount} every month. Track progress anytime in My Bricks.',
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: AppColors.textSecondary,
                fontSize: 13,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 22),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Get.back(),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.textSecondary,
                      side: const BorderSide(color: AppColors.inputBorder),
                      minimumSize: const Size(0, 46),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text('Close'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      Get.back();
                      Get.find<MainShellController>().changeTab(
                        2,
                      ); // My Bricks / Investments tab
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.accent,
                      foregroundColor: Colors.white,
                      minimumSize: const Size(0, 46),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text(
                      'View Plan',
                      style: TextStyle(fontWeight: FontWeight.w700),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
