import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:real_estate/core/theme/controllers/theme_controller.dart';
import 'core/services/auth_service.dart';
import 'core/theme/app_theme.dart';
import 'core/theme/app_colors.dart';
import 'modules/auth/controllers/auth_controller.dart';
import 'modules/auth/bindings/auth_binding.dart';
import 'routes/app_routes.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await GetStorage.init();

  Get.put(AuthService(), permanent: true);
  Get.put(ThemeController(), permanent: true);

  runApp(const BharatSqftApp());
}

class BharatSqftApp extends StatelessWidget {
  const BharatSqftApp({super.key});

  @override
  Widget build(BuildContext context) {
    final authService    = Get.find<AuthService>();
    final themeCtrl      = Get.find<ThemeController>();

    return Obx(() => GetMaterialApp(
      title:                     'Bharat SQFT',
      debugShowCheckedModeBanner: false,
      theme:                     AppTheme.light,
      darkTheme:                 AppTheme.dark,
      themeMode:                 themeCtrl.isDark.value ? ThemeMode.dark : ThemeMode.light,
      initialRoute:              authService.isLoggedIn ? AppRoutes.home : AppRoutes.login,
      getPages:                  appPages,
      initialBinding:            BindingsBuilder(() {
        Get.put(AuthController());
      }),
    ));
  }
}