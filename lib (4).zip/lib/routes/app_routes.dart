import 'package:get/get.dart';
import '../modules/auth/bindings/auth_binding.dart';
import '../modules/auth/views/login_view.dart';
import '../modules/auth/views/register_view.dart';
import '../modules/home/bindings/home_binding.dart';
import '../modules/home/views/main_shell_view.dart';
import '../modules/properties/bindings/property_detail_binding.dart';
import '../modules/properties/views/property_detail_view.dart';
import '../modules/kyc/bindings/kyc_binding.dart';
import '../modules/kyc/views/kyc_view.dart';
import '../modules/savings/views/my_plans_view.dart';

abstract class AppRoutes {
  static const login          = '/login';
  static const register       = '/register';
  static const home           = '/home';
  static const properties     = '/properties';
  static const propertyDetail = '/properties/detail';
  static const investments    = '/investments';
  static const profile        = '/profile';
  static const kyc            = '/kyc';
  static const myPlans        = '/savings/my-plans'; // matches controller
}

final appPages = [
  GetPage(name: AppRoutes.login,          page: () => const LoginView(),          binding: AuthBinding()),
  GetPage(name: AppRoutes.register,       page: () => const RegisterView(),       binding: AuthBinding()),
  GetPage(name: AppRoutes.home,           page: () => const MainShellView(),      binding: HomeBinding()),
  GetPage(name: AppRoutes.propertyDetail, page: () => const PropertyDetailView(), binding: PropertyDetailBinding()),
  GetPage(name: AppRoutes.kyc,            page: () => const KycView(),            binding: KycBinding()),
  // SavingsController already alive from HomeBinding — no extra binding needed
  GetPage(name: AppRoutes.myPlans,        page: () => const MyPlansView()),
];